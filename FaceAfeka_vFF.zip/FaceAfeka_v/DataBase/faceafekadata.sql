-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 08, 2019 at 08:12 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faceafekadata`
--

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `PostID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Status` varchar(255) DEFAULT NULL,
  `ImgSrc` varchar(255) DEFAULT NULL,
  `Publisher` varchar(45) NOT NULL,
  `Privacy` varchar(45) NOT NULL,
  `Likes` varchar(255) DEFAULT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`PostID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`PostID`, `Status`, `ImgSrc`, `Publisher`, `Privacy`, `Likes`, `Date`) VALUES
(1, 'This is Text Number ONe checking if its big enought', NULL, 'ab', 'Public','abc|', '2019-07-07 06:46:00'),
(2, 'Checking it Again', NULL, 'ab', 'Public', 'abc|', '2019-07-07 06:46:00'),
(3, 'test 5', NULL, 'ab', 'Public', 'abc|', '2019-07-07 06:46:00'),
(4, 'i dont know what to do', NULL, 'ab', 'Public', 'abc|', '2019-07-07 06:46:00'),
(5, 'i want to check it again', NULL, 'ab', 'Public', 'abc|', '2019-07-07 06:46:00'),
(6, 'i test this again ! see if size work', NULL, 'ab', 'Public', 'abc|', '2019-07-08 06:46:00'),
(7, 'i want to check Pictures!',NULL, 'ab', 'Public', 'abc|', '2019-07-07 06:46:00');
-- --------------------------------------------------------

--
-- Table structure for table `post`
--
DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `PostID` INTEGER UNSIGNED NOT NULL,
  `Comment` varchar(255) DEFAULT NULL,
  `Publisher` varchar(45) NOT NULL,
  `Date` datetime NOT NULL,
  `Likes` varchar(255) DEFAULT NULL,
  `commentID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
   FOREIGN KEY (`PostID`) REFERENCES post(`PostID`),
   PRIMARY KEY (`commentID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `post`
--

INSERT INTO `comment` (`PostID`, `Comment`, `Publisher`, `Date`,`Likes`,`commentID`) VALUES
(1, 'This is MY COMMENT 1', 'ab', '2019-07-07 06:46:00','abc|',1),
(1, 'This is MY COMMENT 2', 'ab', '2019-07-07 06:46:00','abc|',2);
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `UserID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `friends` mediumtext,
  `Img` mediumtext,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Password`, `friends`, `Img`) VALUES
(1, 'user1', 'b76078ac1326dd9c34be6a7be0077a8e', NULL, 'images/anonymous.jpg'),
(2, 'user2', '82ad9485d4c41007d1eb299a84833027', NULL, 'images/anonymous.jpg'),
(3, 'user3', 'b722b2efa26a4a016a4815398730a6f1', NULL, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCED4pe8uJ5YNijdCJBDdLzH1ppQ4JsD7tC1bs9DOM3Fom3BX4'),
(53, '2', 'bcbe3365e6ac95ea2c0343a2395834dd', NULL, 'images/anonymous.jpg'),
(65, 'gf', '849511f6ad97948229287443848237dd', 'zzz|abc|ab|ass|raz1|', 'images/anonymous.jpg'),
(63, 'raz1', 'c05ea10aa021a9ce7585d28af9f9c5d9', NULL, 'images/anonymous.jpg'),
(62, 'abc', '32930f7a7db863890758f0c5d7ccfbbf', 'ab|', 'https://i.pinimg.com/originals/28/66/9c/28669c6617ed831cc83c095e4515d986.jpg'),
(61, 'ab', 'aca19aa546644a82dd3f5fb3d3f7a17f', 'ab|gf|ra|abc|2|raz1|user3|zzz|raz|12|3|gh|user2|almog|1|dfddd|', 'images/anonymous.jpg'),
(60, 'zzz', '95ebc3c7b3b9f1d2c40fec14415d3cb8', NULL, 'images/anonymous.jpg'),
(59, 'zz', '02c425157ecd32f259548b33402ff6d3', 'zzz|user3|gf|12|raz1|2|3|raz|1|asdas|', 'images/anonymous.jpg'),
(58, 'ra', 'c8cbce92777166f6253f1c28b2e9d833', NULL, 'https://images.askmen.com/1080x540/2016/01/25-021526-facebook_profile_picture_affects_chances_of_getting_hired.jpg'),
(57, 'raz', '61502886a310ec68475e984e5cf0e118', '12|ddd|gf|', 'images/anonymous.jpg'),
(56, '12', '3a15c7d0bbe60300a39f76f8a5ba6896', NULL, 'images/anonymous.jpg'),
(55, 's', '9f6e6800cfae7749eb6c486619254b9c', NULL, 'images/anonymous.jpg'),
(54, '3', '310dcbbf4cce62f762a2aaa148d556bd', NULL, 'images/anonymous.jpg'),
(51, '1', '698d51a19d8a121ce581499d7b701668', 'ddd|user3|dfddd|user2|546|ra|dddddddd|2|12|user1|jjjjjj|gh|raz1|aff|asdas|78|vvv|ab|', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPzG-ZrLCzD7vE9RHo4XBjszAifVVvF4E3L8loR15jmjRAVbid'),
(66, 'ddd', '11ddbaf3386aea1f2974eee984542152', 'user1|user2|user3|', 'images/anonymous.jpg'),
(68, 'almog', '698d51a19d8a121ce581499d7b701668', 'user1|raz|12|abc|ab|ddd|', 'images/anonymous.jpg'),
(69, 'f', '343d9040a671c45832ee5381860e2996', NULL, 'https://data.whicdn.com/images/320568210/large.jpg'),
(73, 'dfddd', 'bad698d701481dcfefbcdfac03ed0e30', NULL, 'https://i.stack.imgur.com/dWrvS.png'),
(70, 'asdas', '0081ab0a10ce0a05732c67dda3436b3d', NULL, 'images/anonymous.jpg'),
(71, 'asdaa', '37e65a398d992fc7a30422ee4dc7ae98', NULL, 'images/anonymous.jpg'),
(72, 'dddddddd', 'a9e49c7aefe022f0a8540361cce7575c', NULL, 'images/anonymous.jpg'),
(74, '546', '0651279f1f67b3dfd57a0fd8f0668bb2', NULL, 'images/anonymous.jpg'),
(75, '78', '0651279f1f67b3dfd57a0fd8f0668bb2', NULL, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbA_S-umwJfjOJMxEa8UwfL8tIybtMhYApBECdtLrsK0YwATiS'),
(76, 'ffsffd', '9963a8201937149aad915bfe73707848', 's|asdas|dddddddd|78|almog|546|asdaa|dfddd|ab|gf|user3|abc|', 'images/anonymous.jpg'),
(80, 'ggf', 'e527a0e7dc884492a140e9f295f1c030', NULL, 'images/anonymous.jpg'),
(79, '87', '0044deeec43ded19b952125079eb1781', NULL, 'images/anonymous.jpg'),
(78, '33', '2be9bd7a3434f7038ca27d1918de58bd', NULL, 'images/anonymous.jpg'),
(81, 'vvv', '103935fb414d693ba3a5f01a9d9399d3', NULL, 'https://data.whicdn.com/images/320568210/large.jpg'),
(82, 'jjjjjj', '3b6281fa2ce2b6c20669490ef4b026a4', NULL, 'images/anonymous.jpg'),
(83, 'aabb', 'f797333e4d3fd576072be1e13e7a1a31', 'raz1|zz|12|ra|raz|user1|78|87|', 'images/anonymous.jpg'),
(84, 'gh', 'ff06d4e6f72ffef5af8abff13e3a60b1', 'abc|', 'images/anonymous.jpg'),
(85, '4', '550a141f12de6341fba65b0ad0433500', 'ab|12|2|33|', 'images/anonymous.jpg'),
(86, 'aff', 'b54f29bf4af55e138ff12b20d30980bf', NULL, 'images/anonymous.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
