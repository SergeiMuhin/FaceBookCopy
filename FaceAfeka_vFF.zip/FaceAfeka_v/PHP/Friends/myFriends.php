<?php
require_once('..\Functions\checkIfUser.php');
?>
    <link href="../CSS/MyFriends.css" rel='stylesheet' type='text/css' /> 
<script>  
     $(document).ready(function(){  
    
    	//Update the friends list under the id myFriends -R
    	<?php  
        include('showMyFriends.php'); //The id myFriends must be exist -R
    	?>   

    	 $(document).on('click', '.myFriendsList', function(){  
	          
	        var friendToShow = $(this).text();
	        <?php
              include('..\Functions\showPosts.php'); //The id myFriends must be exist -R
            ?>

	      }); 


    	      
     });  
</script>

   <div id="myFriends"></div>

 