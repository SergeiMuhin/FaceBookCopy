<?php

require_once('..\DataBase\connection.php');
require_once('getPostSecondCondition.php');
require_once('..\Functions\getComment.php');
require_once('Liked.php');
 $POSTCOUNT = 8;
 $pathThumb = 'images/thumbs/';
 $pathReal = 'images/upload/';
 
 // Get the Post
if(isset($_POST["username"]))
{
    
    $username=$_POST["username"];// UserName is the Post UserName!
    
    $showUserPost='';
    if(isset($_POST["friendToShow"]))
        $showUserPost=$_POST["friendToShow"];
    $post_array = getPost($username,$conn,$showUserPost); // Get the Array of all post each contain's 6 - S// Return the Array - S
    $output = "<div class='postCss'>";
    $counter = 0;// We know it's Return as $POSTCOUNT ... block is $POSTCOUNT array's - S
    $ImgCreator = array();
    $len = count($post_array);//Check Length of Array so we can Determin if it's the Last one - S
    $arrayCounter = 0;
    $innerHeadCounter=0;
    $headArray = array();// Array that Contain's the Head Info / publisher and so on !

    foreach($post_array as $post)    // Basicly working with all array that i Know each post is $POSTCOUNT !
    {
        $counter++;
        if($counter == 1)
            {
                $status= $post;
            }
        else
            if ($counter == 2)
                {
                    $userimg = $post;
                }
            else 
                {
                    if($counter == 8)
                    {
                        $postid =$post;    // Get the ID
                        
                    }
                    else
                    {
                        // Push to Array the Post INFO (Post)- LEFT always 4..
                        array_push($headArray, $post);
                    }
                }
        // Function to Check if we on last Array element - S
        $arrayCounter++;
        if($counter >= $POSTCOUNT)
        {
                            $counter = 0;
                            $ImgCreator = array();
                            // Making the postHead DIV!
                            $output .= "<div class='postHead'>";
                            $output .= '<a data-fancybox="profile'.$postid.'" href="'.$userimg.'">';
                            $output .= "<img class='small-profile-img-Post' src=".$userimg.">";
                            $output .= '</a>';
                            foreach($headArray as $head)
                            {
                                // Suppost to Have 4 - S
                                $innerHeadCounter++;
                                if($innerHeadCounter == 2)
                                {
                                    $numOfLikes = $head;
                                }
                                else {
                                    // Publisher! Name - S
                                    if($innerHeadCounter == 4)
                                    {
                                        $output .= "<div style='font-weight: bold'>";
                                        $output .='User: '.$head;
                                        $output .= "</div>";
                                    }
                                    else
                                    {
                                                // ---** Head or ImgSrc **--- // Start -S
                                                    
                                                // Publisher! Image - S
                                                if($innerHeadCounter == 5)
                                                {
                                                    
                                                    // Check if ImgSrc is NULL! - S
                                                    $ImageString = $head;
                                                    // Check if this is NULL! img in place or not! - S
                                                    
                                                    if($ImageString != NULL)
                                                    {
                                                        // if not Empty than Imag is there so let's make a thing HERE
                                                        // Explode the IMAGES - S
                                                        $arrayImages=explode("|",$ImageString);
                                                        foreach ($arrayImages as $PostImage) // RUN THE Array! - S
                                                        {
                                                            if($PostImage == '')// Fast check if after Explode we have '' Left !
                                                            {
                                                                // DO nothing
                                                            }
                                                            else 
                                                            {
                                                                
                                                                array_push($ImgCreator,$PostImage); // Create an Image! push all Img's NAMES!
                                                                            // echo "<script>alert('".implode(" ",$ImgCreator)."');</script>";
                                                            }
                                                            
                                                        }
                                                    }
                                                    else 
                                                    {
                                                        //NO images for Post so No use !
                                                    }
                                                    
                                                    
                                                } // Creates the Head ! 
                                                else 
                                                {
                                                    $output .= "<div style='float:right; padding-right:20px;'>";
                                                    $output .=''.$head;
                                                    $output .= "</div>";
                                                }
                                                
                                                  // ---** Head or ImgSrc **--- // Close -S
                                                
                                                
                                    }
                                }
                            }
                            $innerHeadCounter = 0;
                            // Empty the Array So next time wont push to push ! - S
                            $headArray = array();
                            // Close the postHead DIV!
                            $output .= "</div>";
                            $output .= "<div class='postText'>";
                            $output .= $status;
                            $output .= "</div>";
                            // Create Img's HERE
                            foreach ($ImgCreator as $postImg)
                            {
                                
                                $output.= '<a data-fancybox="UploadedImg'.$postid.'" href="'. $pathReal.$postImg.'">';
                                                
                                $output .='<img class="UploadedImg" ';
                                $output .='src="'.$pathThumb.$postImg;
                                $output .='"';
                                $output .='>';
                                
                                $output .='</a>';
                                
                            }
                            // Create the Lower Div PostButton's - S
                            $output .= "<div class='postButton'>";
                            $output .= "<div style='float:left;padding-top:10px;color:red;font-weight: bold'>";
                            // Check if Already Like'd - S
                            if(getLikes($postid,$username))
                            {
                                $output .= "<button type='button' id='$postid' style='margin-right:10px;'  class='liked' >";
                                $output .= "<i class='fa fa-heart'></i>";
                                $output .= "<span>Liked</span>";
                                $output .= "</button>";
                                $output .= ''.$numOfLikes;
                                $output .= "</div>";
                            }
                            else 
                            {
                            $output .= "<button type='button' id='$postid' style='margin-right:10px;'  class='button-like' >";
                            $output .= "<i class='fa fa-heart'></i>";
                            $output .= "<span>Like</span>";
                            $output .= "</button>";
                            $output .= ''.$numOfLikes;
                            $output .= "</div>";
                            }
                            // Close the Lower Div PostButton's - S
                            $output .= "<textarea id='text$postid' class='CommentText' name='CommentText' placeholder='Comment...' style='width:100%; border-radius: 5px; margin-top:15px;'></textarea>";
                            $output .= "<button type='button' id='$postid' class='CommentButton'>Comment</button>";
                            $output .= "</div>";
                            
                            // Here Gonna Get Comment's IF here!
                            
                            $Comment_HTML = getComment($postid,$conn); // Get Array of all Comment's! - S
                            // Only IF comment's Exist ! - S
                                
                                $output .= $Comment_HTML;
 
                            
                            // Close Comment's!
                            
                            
                            // Close Div the postCSS class - S
                            $output .= "</div>";
                            // Function to Check if we on last Array element - S
                            // ***--- Closing and getting the POST ID!
                            
                            if($arrayCounter != $len)
                            {                
                                $output .= "<div class='postCss'>"; // Open Div the postCSS class - S
                                
                            }
        }
    }

    echo $output;
}

?> 