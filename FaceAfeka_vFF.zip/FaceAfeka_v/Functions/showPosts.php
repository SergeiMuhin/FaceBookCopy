   if (typeof friendToShow === 'undefined') {
    var friendToShow="";
}
   
   
   $.ajax({
	       type: "POST",
	       url: 'PHP/Post_code.php',
	       data: {username: "<?php echo $_SESSION['username']; ?>",friendToShow:friendToShow},
	       success: function(data){
	    	   $('#post-container').fadeIn(data);
               $('#post-container').html(data);
	       }
	   });