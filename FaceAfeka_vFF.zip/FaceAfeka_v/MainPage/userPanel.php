<?php
require_once('..\Functions\checkIfUser.php');
?>

<link href="../CSS/userPanel.css" rel='stylesheet' type='text/css' /> 


<script>
$(document).ready(function(){
	  $("#myProfile-container-max").hide();
  $(".form-control").click(function(){
    

var choice = $( "#sel1" ).val();

switch(choice) {
case "My friends":
	  showOrHide(true,"#myFriends-container",false,"#myProfile-container-max",false,"#playAGame-container");
	  showAllPosts();
	  break;
case "My Profile":
		  showOrHide(false,"#myFriends-container",true,"#myProfile-container-max",false,"#playAGame-container");
		  showMyPosts();  
	  break;
case "Play a Game":
	showOrHide(false,"#myFriends-container",false,"#myProfile-container-max",true,"#playAGame-container");
  break;
}



  });
});

function showOrHide() {
   
    for (var i=0; i < arguments.length; i++) {
        if(arguments[i++])
        	$(arguments[i]).show();
        else
        	$(arguments[i]).hide();
    }
}


function showMyPosts()
{
var friendToShow = <?php echo $_SESSION['username']; ?>;
<?php
  include('..\Functions\showPosts.php'); //The id myFriends must be exist -R
?>
  
}


function showAllPosts()
{
	var friendToShow = "";
<?php
  include('..\Functions\showPosts.php'); //The id myFriends must be exist -R
?>
  
}

</script>

<div class="UserPanel">

    
    <select class="form-control" id="sel1" name="sellist1">
        <option>My friends</option>
        <option>My Profile</option>
        <option>Play a Game</option>
      </select>
      
      
    <div id="myFriends-container">
    <?php
    require_once('..\PHP\Friends\myFriends.php');
    ?>
    </div>
    
    
        <div id="myProfile-container-max">
        <?php
    require_once('..\PHP\MyProfile\myProfile.php');
    ?>
    </div>


   <div id="playAGame-container">
    </div>


</div>